package se.liu.ida.adany869.tddc69.lab2;

/**
 * Creates an interface to be implemented by objects wanting to know when a board has changed.
 */

public interface BoardListener {
    public void boardChanged();
}
